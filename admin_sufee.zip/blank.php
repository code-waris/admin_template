<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mpay || Profile</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
	


</head>

<body>
    <!-- Left Panel -->
	
	<?php include_once("include/menu.php"); ?>

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <?php include_once("include/header.php"); ?>
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Update Profile</h1>
                    </div>
                </div>
            </div>
            
        </div>

        <div class="col-lg-6">
						<div class="card">
							<div class="card-header">
								<strong>User</strong> Details
							</div>
							<div class="card-body card-block">
								<form action="" method="post" class="form-horizontal">
									<div class="row form-group">
										<div class="col col-md-3"><label for="hf-email" class=" form-control-label">Full name</label></div>
										<div class="col-12 col-md-9"><input type="email" value="" disabled  class="form-control"></div>
									</div>
									<div class="row form-group">
										<div class="col col-md-3"><label for="hf-password" class=" form-control-label">Email</label></div>
										<div class="col-12 col-md-9"><input type="password" value="" disabled readonly  class="form-control"></div>
									</div>
									<div class="row form-group">
										<div class="col col-md-3"><label for="hf-password" class=" form-control-label">Sponsor Id</label></div>
										<div class="col-12 col-md-9"><input type="password" value="" disabled readonly  class="form-control"></div>
									</div><div class="row form-group">
										<div class="col col-md-3"><label for="hf-password" class=" form-control-label">Sp Name</label></div>
										<div class="col-12 col-md-9"><input type="password" value="" disabled readonly  class="form-control"></div>
									</div>
									<div class="row form-group">
										<div class="col col-md-3"><label for="hf-password" class=" form-control-label">Registration</label></div>
										<div class="col-12 col-md-9"><input type="password" value="" disabled readonly class="form-control"></div>
									</div>
								</form>
							</div>
							
						</div>
					</div>
       
	
				   
				
	</div><!-- /#right-panel -->
                                <!-- Right Panel -->


                            <script src="vendors/jquery/dist/jquery.min.js"></script>
                            <script src="vendors/popper.js/dist/umd/popper.min.js"></script>

                            <script src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
                            <script src="vendors/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.min.js"></script>

                            <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
                            <script src="assets/js/main.js"></script>
</body>
</html>
