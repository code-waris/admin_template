<?php 
include('include/config.php');
session_destroy();
die(header("location:login.php"));


?>