
<?php
include('include/config.php'); 

if(isset($_GET["id"]))
{
   $spon_id=str_rot13((trim($_GET["id"])));
   $sponquery=mysql_query("select username,fullname from registration where username='".$spon_id."'");
   $getid=mysql_fetch_array($sponquery);
   if(mysql_num_rows($sponquery)==0)
   {
    header("location:register.php");
}

}
if(isset($_POST['submit']))
{

    @$msg='';
    $sponserid=trim($_POST['sp_id']);  
    $sponsername=trim($_POST['sp_name']);
    $pin=trim($_POST['pin']);    
    $mobile=trim($_POST['mobile']); 
    @$fullname=trim($_POST['name']);
    $full_name=mysql_real_escape_string($fullname);
    $email=trim($_POST['email']);
    $email_id=mysql_real_escape_string($email);
    $pass=trim($_POST['password']);
    $password=mysql_real_escape_string($pass);
    $repass=trim($_POST['repassword']);
    $repassword=mysql_real_escape_string($repass);

    $pincount=mysql_num_rows(mysql_query("select pinnumber from pin_generate where pinnumber='".$pin."' and status='open'"));
    if(empty($pin)){echo '<script>alert("please enter Pin");</script>';}
    elseif($pincount<1){echo '<script>alert("please enter Valid pin");</script>';}
    elseif(empty($sponserid)){echo '<script>alert("please enter sponserid");</script>';}
    elseif(empty($full_name)){echo '<script>alert("please enter Full Name");</script>';}
    elseif(empty($email)){echo '<script>alert("please enter Email");</script>';}
    elseif(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email)){echo '<script>alert("please enter correct email");</script>';}
    elseif(empty($mobile)){echo '<script>alert("please enter Mobile Number");</script>';}
    elseif(empty($password)){echo '<script>alert("please enter password");</script>';}
    elseif(empty($repassword)){echo '<script>alert("please enter repassword");</script>';}
    elseif($password!=$repassword){echo '<script>alert("please enter same password");</script>';}
    else
    {


        $userid='MN'.(rand(111111,444444)+rand(333333,555555));
        $sp_id=mysql_fetch_array(mysql_query("select id,sp_id from registration where username='".$sponserid."'"));
        $query="insert into registration set fullname='".$full_name."',username='".$userid."',mail='".$email_id."',password='".$password."',
        mobile='".$mobile."',sp_id='".$sp_id['id']."',sponserid='".$sponserid."',turnover=0";
        
        $full_query=mysql_query($query);
        if($full_query)
        {

            $headers = "From: Support OurSafalta <Support@OurSafalta.com> \r\n";
                    //mail($email,"Welcome to OurSafalta", "Welcome to OurSafalta.com your User Id is : ".$userid." and password is : ".$password."", $headers);
            $comm_amount=array(130,50,40,30,20,10,10,10,10,10,10,10);
            $last_id=mysql_insert_id();
            //$rows=mysql_num_rows(mysql_query("select level from worklevel where userid='".$sp_id['id']."'"));
            //$rows+=1;
            //mysql_query("insert into worklevel set userid='".$sp_id['id']."',level='".$rows."'");
            mysql_query("UPDATE `pin_generate` SET `status` = 'close',usedbyid='".$last_id."',modifieddate='".date('Y-m-d')."' WHERE pinnumber='".$pin."'");
            mysql_query("insert into totalincome set userid='".$last_id."',total='0.00'");
            mysql_query("update registration set turnover=turnover+1 where id!='".$last_id."'");
            mysql_query("insert into workwallet set userid='".$sp_id['id']."',amount='".$comm_amount[0]."'");
            mysql_query("UPDATE `totalincome` SET `total` = total+'".$comm_amount[0]."' WHERE userid = '".$sp_id['id']."'");
            mysql_query("UPDATE `registration` SET downline =concat(downline,',".$last_id."'),team=team+1,direct=direct+1 WHERE id = '".$sp_id['id']."'");
            $prevsponid=$sp_id['id'];
            
            for($i=1; $i<12; $i++)
            {
                //echo "select id,sp_id from registration where sp_id='".$prevsponid."'";

                $sp_idd=mysql_fetch_array(mysql_query("select sp_id from registration where id='".$prevsponid."'"));
                
                
                if($sp_idd['sp_id']==0)
                {   
                    //mysql_query("UPDATE `registration` SET downline =concat(downline,'a".$last_id."') WHERE id = '".$prevsponid."'");
                    break;
                }else
                {
                //echo "UPDATE `registration` SET downline =concat(downline,'a".$last_id."') WHERE id = '".$prevsponid."'";
                    mysql_query("insert into workwallet set userid='".$sp_idd['sp_id']."',amount='".$comm_amount[$i]."'");
                    mysql_query("UPDATE `totalincome` SET `total` = total+'".$comm_amount[$i]."' WHERE userid = '".$sp_idd['sp_id']."'");
                    mysql_query("UPDATE `registration` SET downline =concat(downline,',".$last_id."'),team=team+1 WHERE id = '".$sp_idd['sp_id']."'");
                    $prevsponid=$sp_idd['sp_id'];
                    unset($sp_idd);

                }
            }
            $msg="Successfully Registered Your UserId is ".$userid;
            //echo '<script>alert("Regisration Successfully");window.location.assign("index.php")</script>';
            
        }
        else
        {
            echo '<script>alert("New Registration Not Sucessfully");</script>';
        }
        
        
        
    }       
}



?>


<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mpay || SignUp</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body class="bg-dark">


    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                    <a href="../index.php">
                        <span>Mpay1000</span>
                    </a>
                </div>
                <div class="login-form">
                    <form action="" method="post">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Sponsor Id" name="sp_id">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Sponsor Name" name="sp_name">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Pin" name="pin">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="User Name" name="username">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Full Name" name="name">
                        </div>
                        <div class="form-group">
                            <input type="Email" class="form-control" placeholder="Email" name="mail">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" maxlength="10" placeholder="Mobile" name="mobile">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Password" name="pass">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Re Password" name="repass">
                        </div>
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" required="true"> Agree the terms and policy
                            </label>
                        </div>
                        <input type="submit" name="submit" value="Submit" class="btn btn-primary btn-flat m-b-30 m-t-30">
                        
                        <div class="register-link m-t-15 text-center">
                            <p>Already have account ? <a href="#"> Sign in</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
